from .ts3proxy import main

main()
